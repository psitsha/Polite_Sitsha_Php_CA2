<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Car Showroom, Inc.</title>
        <link href="css/stylesheet.css" rel="stylesheet" type="text/css"/>         
    </head>
    <body>
        <?php
        // put your code here
        ?>
        <a name="top"></a>
        <div id="container">

            <a href="index.php">
                <img class="banner-img" src="img/fleet.jpg" alt="Banner" />
            </a>
            <div class="topnav">
                <a href="index.php">Home</a>
                <a href="add_car_form.php">Add Car</a>
                <a href="cars_list.php">List All Cars</a>
                <a href="add_salesman_form.php">Add Salesman</a>
                <a href="salesman_list.php">List All Salesmen</a>
            </div>

            <div style="padding-left:16px">